# hawtat-sudair — Walaa GMS provider network

From the Walaa GMS provider list (file `Walla_Updated_network.xlsx`, sheet `GLOBEMED SAUDI`, network "Walaa GMS standard Full Network", header date 07-08-2025). Region: Riyadh.
Each row states every GMS tier the provider accepts in the source list. A dash in the source means that tier is not covered there.
"Emergency & referral only" is carried through from the source's own value: the provider is limited to emergency and referral cases on that tier, which is not the same as a normal accepted visit.
**2 providers** in this city.

| Provider | Network | Type | Address | Telephone |
|---|---|---|---|---|
| Safa Al Oroba Medical complex | **VIP, A, B, C, C+, C+ PC** | Clinic | Shifa District | 016-5399999 |
| Al Salman Optical - Hota Suder | **VIP, A, B, C, C+, C+ PC** | Optical | Hota Suder Dis. | 011-4113661 |

# umluj — Walaa GMS provider network

From the Walaa GMS provider list (file `Walla_Updated_network.xlsx`, sheet `GLOBEMED SAUDI`, network "Walaa GMS standard Full Network", header date 07-08-2025). Region: Tabuk.
Each row states every GMS tier the provider accepts in the source list. A dash in the source means that tier is not covered there.
"Emergency & referral only" is carried through from the source's own value: the provider is limited to emergency and referral cases on that tier, which is not the same as a normal accepted visit.
**3 providers** in this city.

| Provider | Network | Type | Address | Telephone |
|---|---|---|---|---|
| Al Salamah & Al Hayah Complex | **VIP, A, B, C, C+, C+ PC** | Clinic | Batha District | 014-3820222 |
| EINAYAULHAWRA POLYCLINIC | **VIP, A, B, C, C+** | Clinic | Al Dawhiy Dis | 143822228 |
| Ummloj General Hospital - MOH | **VIP, A, B (emergency & referral only), C (emergency & referral only), C+ (emergency & referral only), C+ PC (emergency & referral only)** | Hospital | King abdallah Dis. | 014-3820700 |

# darma — Walaa GMS provider network

From the Walaa_GMS_Updated_network.xlsx provider list, dated 07-08-2025 (sheet: GLOBEMED SAUDI — Walaa GMS standard Full Network). Region: Riyadh. The source list holds the network as it stands at the file's date; it is not a live feed.
Each row states the GMS card tiers the provider accepts. A dash means the tier is not covered there. 'Emergency & Referral' in the source means the provider only takes emergency and referral cases, not elective visits.
**2 providers** in this city.

| Provider | Type | Tier: VIP | Tier: A | Tier: B | Tier: C | Tier: C+ | Extra | Owner | District | Phone | Source code |
|---|---|---|---|---|---|---|---|---|---|---|
| Ocean Medical Complex | CLINIC | yes | yes | yes | yes | yes | not covered | Private | Al Badia | 597207458 | C553201 |
| Darma Hospital - MOH | HOSPITAL | yes | yes | emergency & referral only | emergency & referral only | emergency & referral only | emergency & referral only | MOH | Darmaa Dis. | 011-5220607 | H521021 |

# baqaa — Walaa GMS provider network

From the Walaa_GMS_Updated_network.xlsx provider list, dated 07-08-2025 (sheet: GLOBEMED SAUDI — Walaa GMS standard Full Network). Region: Hail. The source list holds the network as it stands at the file's date; it is not a live feed.
Each row states the GMS card tiers the provider accepts. A dash means the tier is not covered there. 'Emergency & Referral' in the source means the provider only takes emergency and referral cases, not elective visits.
**2 providers** in this city.

| Provider | Type | Tier: VIP | Tier: A | Tier: B | Tier: C | Tier: C+ | Extra | Owner | District | Phone | Source code |
|---|---|---|---|---|---|---|---|---|---|---|
| Al Lewa`a Med. Clinic - Baqa`a | CLINIC | yes | yes | yes | yes | yes | yes | Private | Plan 316 District | 016-5271122 | C2056 |
| Baqa`a Medical Complex | CLINIC | yes | yes | yes | yes | yes | yes | Private | Al Mokhatat Dist. | 016-5272255 | C508131 |

# khulais — Walaa GMS provider network

From the Walaa_GMS_Updated_network.xlsx provider list, dated 07-08-2025 (sheet: GLOBEMED SAUDI — Walaa GMS standard Full Network). Region: Makkah. The source list holds the network as it stands at the file's date; it is not a live feed.
Each row states the GMS card tiers the provider accepts. A dash means the tier is not covered there. 'Emergency & Referral' in the source means the provider only takes emergency and referral cases, not elective visits.
**2 providers** in this city.

| Provider | Type | Tier: VIP | Tier: A | Tier: B | Tier: C | Tier: C+ | Extra | Owner | District | Phone | Source code |
|---|---|---|---|---|---|---|---|---|---|---|
| Majid Muhammad Al-Bishri Complex - Khulais (Previously Al Bishri Medical Complex - Khulais) | CLINIC | yes | yes | yes | yes | yes | yes | Private | Al Daf District | 012-2653113 | C531881 |
| Khulais General Hospital | HOSPITAL | yes | yes | not covered | not covered | not covered | not covered | MOH | Al Faysalih Dis | 055 046 2462 | H528928 |

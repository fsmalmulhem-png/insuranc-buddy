# albarak — Gulf Insurance Group (GIG) provider network

From GIG's public provider locator (see `../sources/index.md`).
**1 providers** in this city.

| Provider | Network | Type | Address | Telephone |
|---|---|---|---|---|
| Nahdi Pharmacy-7374 | **E** | Pharmacy | Albarak, albarak, albarak | 966544147963 |

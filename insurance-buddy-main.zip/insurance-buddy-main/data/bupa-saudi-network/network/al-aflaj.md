# Al Aflaj — Bupa provider network

Extracted from the Bupa Arabia published network spreadsheets (see `../sources/index.md`). Source rows in the original files: 2 provider codes in this city.

**How to read the Tiers column.** Each cell lists the Bupa network levels under which the provider appears *in the source spreadsheet for that level*. A provider listed with 3 levels is in all 3; a provider listed once is only in that one. Never extend a row to a level it does not name.

| Provider | Provider code | Type | Tiers accepted | Telephone | Source |
|---|---|---|---|---|---|
| Al Kamal Medical Clinic | 22007 | Polyclinic | NW7+, NW6, NW5, NWS, NWM | 0116823311 | `Household-help-network.xlsx`, `saudi-parent-network.xlsx` |
| Al Qarah Medical Complex | 24167 | Polyclinic | NW7+, NW6, NW5, NWS | 0116827777 | `Household-help-network.xlsx`, `saudi-parent-network.xlsx` |

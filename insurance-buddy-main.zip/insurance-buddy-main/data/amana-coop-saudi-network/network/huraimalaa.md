# Huraimalaa — Amana Cooperative Insurance provider network

Extracted from Amana's own published network PDFs (see `../sources/index.md`).
This city has 1 providers.

| Provider | Code | Type | Owner | Network list | Telephone |
|---|---|---|---|---|---|
| Huraymala General Hospital | H539581 | Hospital | MOH | Full (existing policies), SME Basic | — |
